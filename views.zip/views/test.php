<body>

<fieldset>
<legend>Photo upload errors!</legend>
<form>
<?php echo $error;?>
</form>
</fieldset>
</body>